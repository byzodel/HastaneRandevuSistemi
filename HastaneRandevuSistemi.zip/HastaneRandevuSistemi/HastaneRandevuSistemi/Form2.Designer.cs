﻿namespace HastaneRandevuSistemi
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.btnBeyin = new System.Windows.Forms.Button();
            this.btnKadın = new System.Windows.Forms.Button();
            this.btnAile = new System.Windows.Forms.Button();
            this.btnNöroloji = new System.Windows.Forms.Button();
            this.btnKBB = new System.Windows.Forms.Button();
            this.btnPsikiyatri = new System.Windows.Forms.Button();
            this.btnGöz = new System.Windows.Forms.Button();
            this.btnOnkoloji = new System.Windows.Forms.Button();
            this.btnKardiyoloji = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnBeyin
            // 
            this.btnBeyin.BackColor = System.Drawing.Color.White;
            this.btnBeyin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBeyin.BackgroundImage")));
            this.btnBeyin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBeyin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBeyin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnBeyin.Location = new System.Drawing.Point(167, 75);
            this.btnBeyin.Name = "btnBeyin";
            this.btnBeyin.Size = new System.Drawing.Size(130, 141);
            this.btnBeyin.TabIndex = 0;
            this.btnBeyin.UseVisualStyleBackColor = false;
            this.btnBeyin.Click += new System.EventHandler(this.btnBeyin_Click);
            // 
            // btnKadın
            // 
            this.btnKadın.BackColor = System.Drawing.Color.White;
            this.btnKadın.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnKadın.BackgroundImage")));
            this.btnKadın.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnKadın.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKadın.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKadın.Location = new System.Drawing.Point(321, 75);
            this.btnKadın.Name = "btnKadın";
            this.btnKadın.Size = new System.Drawing.Size(133, 141);
            this.btnKadın.TabIndex = 1;
            this.btnKadın.UseVisualStyleBackColor = false;
            this.btnKadın.Click += new System.EventHandler(this.btnKadın_Click);
            // 
            // btnAile
            // 
            this.btnAile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(173)))), ((int)(((byte)(216)))), ((int)(((byte)(230)))));
            this.btnAile.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAile.BackgroundImage")));
            this.btnAile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAile.Location = new System.Drawing.Point(475, 75);
            this.btnAile.Name = "btnAile";
            this.btnAile.Size = new System.Drawing.Size(133, 141);
            this.btnAile.TabIndex = 2;
            this.btnAile.UseVisualStyleBackColor = false;
            this.btnAile.Click += new System.EventHandler(this.btnAile_Click);
            // 
            // btnNöroloji
            // 
            this.btnNöroloji.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(173)))), ((int)(((byte)(216)))), ((int)(((byte)(230)))));
            this.btnNöroloji.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnNöroloji.BackgroundImage")));
            this.btnNöroloji.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNöroloji.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNöroloji.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnNöroloji.Location = new System.Drawing.Point(167, 242);
            this.btnNöroloji.Name = "btnNöroloji";
            this.btnNöroloji.Size = new System.Drawing.Size(133, 141);
            this.btnNöroloji.TabIndex = 3;
            this.btnNöroloji.UseVisualStyleBackColor = false;
            this.btnNöroloji.Click += new System.EventHandler(this.btnNöroloji_Click);
            // 
            // btnKBB
            // 
            this.btnKBB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(173)))), ((int)(((byte)(216)))), ((int)(((byte)(230)))));
            this.btnKBB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnKBB.BackgroundImage")));
            this.btnKBB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnKBB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKBB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKBB.Location = new System.Drawing.Point(321, 242);
            this.btnKBB.Name = "btnKBB";
            this.btnKBB.Size = new System.Drawing.Size(133, 141);
            this.btnKBB.TabIndex = 4;
            this.btnKBB.UseVisualStyleBackColor = false;
            this.btnKBB.Click += new System.EventHandler(this.btnKBB_Click);
            // 
            // btnPsikiyatri
            // 
            this.btnPsikiyatri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(173)))), ((int)(((byte)(216)))), ((int)(((byte)(230)))));
            this.btnPsikiyatri.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPsikiyatri.BackgroundImage")));
            this.btnPsikiyatri.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPsikiyatri.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPsikiyatri.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnPsikiyatri.Location = new System.Drawing.Point(475, 242);
            this.btnPsikiyatri.Name = "btnPsikiyatri";
            this.btnPsikiyatri.Size = new System.Drawing.Size(133, 141);
            this.btnPsikiyatri.TabIndex = 5;
            this.btnPsikiyatri.UseVisualStyleBackColor = false;
            this.btnPsikiyatri.Click += new System.EventHandler(this.btnPsikiyatri_Click);
            // 
            // btnGöz
            // 
            this.btnGöz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(173)))), ((int)(((byte)(216)))), ((int)(((byte)(230)))));
            this.btnGöz.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGöz.BackgroundImage")));
            this.btnGöz.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnGöz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGöz.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGöz.Location = new System.Drawing.Point(167, 411);
            this.btnGöz.Name = "btnGöz";
            this.btnGöz.Size = new System.Drawing.Size(133, 141);
            this.btnGöz.TabIndex = 6;
            this.btnGöz.UseVisualStyleBackColor = false;
            this.btnGöz.Click += new System.EventHandler(this.btnGöz_Click);
            // 
            // btnOnkoloji
            // 
            this.btnOnkoloji.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(173)))), ((int)(((byte)(216)))), ((int)(((byte)(230)))));
            this.btnOnkoloji.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnOnkoloji.BackgroundImage")));
            this.btnOnkoloji.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnOnkoloji.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOnkoloji.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnOnkoloji.Location = new System.Drawing.Point(321, 411);
            this.btnOnkoloji.Name = "btnOnkoloji";
            this.btnOnkoloji.Size = new System.Drawing.Size(133, 141);
            this.btnOnkoloji.TabIndex = 7;
            this.btnOnkoloji.UseVisualStyleBackColor = false;
            this.btnOnkoloji.Click += new System.EventHandler(this.btnOnkoloji_Click);
            // 
            // btnKardiyoloji
            // 
            this.btnKardiyoloji.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(173)))), ((int)(((byte)(216)))), ((int)(((byte)(230)))));
            this.btnKardiyoloji.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnKardiyoloji.BackgroundImage")));
            this.btnKardiyoloji.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnKardiyoloji.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKardiyoloji.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKardiyoloji.Location = new System.Drawing.Point(475, 411);
            this.btnKardiyoloji.Name = "btnKardiyoloji";
            this.btnKardiyoloji.Size = new System.Drawing.Size(133, 141);
            this.btnKardiyoloji.TabIndex = 8;
            this.btnKardiyoloji.UseVisualStyleBackColor = false;
            this.btnKardiyoloji.Click += new System.EventHandler(this.btnKardiyoloji_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(173)))), ((int)(((byte)(216)))), ((int)(((byte)(230)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(67)))), ((int)(((byte)(103)))));
            this.label1.Location = new System.Drawing.Point(301, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 32);
            this.label1.TabIndex = 9;
            this.label1.Text = "Branş Seçimi";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnKardiyoloji);
            this.Controls.Add(this.btnOnkoloji);
            this.Controls.Add(this.btnGöz);
            this.Controls.Add(this.btnPsikiyatri);
            this.Controls.Add(this.btnKBB);
            this.Controls.Add(this.btnNöroloji);
            this.Controls.Add(this.btnAile);
            this.Controls.Add(this.btnKadın);
            this.Controls.Add(this.btnBeyin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBeyin;
        private System.Windows.Forms.Button btnKadın;
        private System.Windows.Forms.Button btnAile;
        private System.Windows.Forms.Button btnNöroloji;
        private System.Windows.Forms.Button btnKBB;
        private System.Windows.Forms.Button btnPsikiyatri;
        private System.Windows.Forms.Button btnGöz;
        private System.Windows.Forms.Button btnOnkoloji;
        private System.Windows.Forms.Button btnKardiyoloji;
        private System.Windows.Forms.Label label1;
    }
}